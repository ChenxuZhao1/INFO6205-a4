package edu.neu.coe.info6205.sort.classic;

public interface Classify<X> {
    int classify();
}
