package edu.neu.coe.info6205.graphs.gis;

import org.junit.Test;

public class Position_SphericalTest {

    @Test
    public void getLatitude() {
    }

    @Test
    public void getLongitude() {
    }

    @Test
    public void getX() {
    }

    @Test
    public void getY() {
    }

    @Test
    public void toStringTest() {
    }
}